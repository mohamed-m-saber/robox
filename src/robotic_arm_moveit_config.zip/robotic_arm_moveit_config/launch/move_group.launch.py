# from moveit_configs_utils import MoveItConfigsBuilder
# from moveit_configs_utils.launches import generate_move_group_launch


# def generate_launch_description():
#     moveit_config = MoveItConfigsBuilder("robotic_arm", package_name="robotic_arm_moveit_config").to_moveit_configs()
#     return generate_move_group_launch(moveit_config)


from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_move_group_launch
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Initialize MoveIt configuration
    moveit_config = MoveItConfigsBuilder("robotic_arm", package_name="robotic_arm_moveit_config").to_moveit_configs()

    # Explicitly set planning pipeline
    moveit_config.planning_pipelines["pipelines"] = ["ompl"]

    # Load moveit_controllers.yaml
    moveit_controllers_file = os.path.join(
        get_package_share_directory("robotic_arm_moveit_config"),
        "config",
        "moveit_controllers.yaml"
    )

    # Generate move_group launch
    launch_description = generate_move_group_launch(moveit_config)

    # Add robot_state_publisher with debug logging
    launch_description.add_action(
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="robot_state_publisher",
            output="screen",
            parameters=[moveit_config.robot_description],
            namespace="/",
            arguments=["--ros-args", "--log-level", "debug"]
        )
    )

    # Add ros2_control node with debug logging
    launch_description.add_action(
        Node(
            package="controller_manager",
            executable="ros2_control_node",
            parameters=[
                moveit_config.robot_description,
                {"use_sim_time": False},
                os.path.join(
                    get_package_share_directory("robotic_arm_moveit_config"),
                    "config",
                    "ros2_controllers.yaml"
                )
            ],
            output="screen",
            namespace="/",
            arguments=["--ros-args", "--log-level", "debug"]
        )
    )

    # Add controller spawners
    for controller in ["joint_state_broadcaster", "arm_controller", "gripper_controller"]:
        launch_description.add_action(
            Node(
                package="controller_manager",
                executable="spawner",
                arguments=[controller],
                output="screen",
                namespace="/"
            )
        )

    # Add move_group node with debug logging
    launch_description.add_action(
        Node(
            package="moveit_ros_move_group",
            executable="move_group",
            name="move_group",
            output="screen",
            parameters=[
                moveit_config.robot_description,
                moveit_config.robot_description_semantic,
                moveit_config.planning_pipelines,
                moveit_config.planning_scene_monitor,
                moveit_controllers_file,  # Load controllers explicitly
                {"use_sim_time": False}
            ],
            namespace="/",
            arguments=["--ros-args", "--log-level", "debug"]
        )
    )

    return launch_description