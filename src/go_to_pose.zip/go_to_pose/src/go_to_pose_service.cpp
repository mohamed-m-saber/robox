#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <moveit/move_group_interface/move_group_interface.hpp>

class GoToPoseService : public rclcpp::Node
{
public:
  GoToPoseService() : Node("go_to_pose_service")
  {
    using namespace std::placeholders;
    service_ = this->create_service<std_srvs::srv::Trigger>(
      "go_to_pose_service",
      std::bind(&GoToPoseService::handle_request, this, _1, _2));

    move_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(shared_from_this(), "arm");

    RCLCPP_INFO(this->get_logger(), "GoToPoseService is ready.");
  }

private:
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr service_;
  std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;

  void handle_request(
    const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response)
  {
    geometry_msgs::msg::Pose target_pose;
    target_pose.position.x = 0.4;
    target_pose.position.y = 0.0;
    target_pose.position.z = 0.4;
    target_pose.orientation.w = 1.0;

    move_group_->setPoseTarget(target_pose);
    auto success = static_cast<bool>(move_group_->move());

    response->success = success;
    response->message = success ? "Motion executed successfully." : "Motion execution failed.";
  }
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);

  auto node = std::make_shared<GoToPoseService>();

  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}

